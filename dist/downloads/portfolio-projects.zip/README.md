# Synthetic Healthcare Analytics Project Pack

This is the analysis-only download. It contains data, SQL, Python, case studies, Power BI assets, and documentation. The complete portfolio delivery also includes the website.

Run `python3 python/build_data.py` followed by `python3 python/validate.py`. Python 3.9+; no external dependencies. The generator creates a browser data asset in dist/assets, but this archive does not include website HTML. All records and results are synthetic. Start with docs/data-dictionary.md and powerbi/README.md.
